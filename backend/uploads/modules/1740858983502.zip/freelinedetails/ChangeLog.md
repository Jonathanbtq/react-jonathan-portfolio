# CHANGELOG FREELINEDETAILS FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.0

Initial version
**[NEW]** Initial by Jonathan Botquin