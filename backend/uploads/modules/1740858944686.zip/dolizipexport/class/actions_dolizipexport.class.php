<?php
/* Copyright (C) 2025 SuperAdmin
 * Copyright (C) 2024		MDW							<mdeweerd@users.noreply.github.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    dolizipexport/class/actions_dolizipexport.class.php
 * \ingroup dolizipexport
 * \brief   Example hook overload.
 *
 * Put detailed description here.
 */

require_once DOL_DOCUMENT_ROOT.'/core/class/commonhookactions.class.php';

/**
 * Class ActionsDoliZipExport
 */
class ActionsDoliZipExport extends CommonHookActions
{
	/**
	 * @var DoliDB Database handler.
	 */
	public $db;

	/**
	 * @var string Error code (or message)
	 */
	public $error = '';

	/**
	 * @var array Errors
	 */
	public $errors = array();


	/**
	 * @var array Hook results. Propagated to $hookmanager->resArray for later reuse
	 */
	public $results = array();

	/**
	 * @var ?string String displayed by executeHook() immediately after return
	 */
	public $resprints;

	/**
	 * @var int		Priority of hook (50 is used if value is not defined)
	 */
	public $priority;


	/**
	 * Constructor
	 *
	 *  @param		DoliDB		$db      Database handler
	 */
	public function __construct($db)
	{
		$this->db = $db;
	}


	/**
	 * Execute action
	 *
	 * @param	array			$parameters		Array of parameters
	 * @param	CommonObject    $object         The object to process (an invoice if you are in invoice module, a propale in propale's module, etc...)
	 * @param	string			$action      	'add', 'update', 'view'
	 * @return	int         					Return integer <0 if KO,
	 *                           				=0 if OK but we want to process standard actions too,
	 *                            				>0 if OK and we want to replace standard actions.
	 */
	public function getNomUrl($parameters, &$object, &$action)
	{
		global $db, $langs, $conf, $user;
		$this->resprints = '';
		return 0;
	}

	// Fonction récursive pour récupérer tous les fichiers (y compris images)
    function getFilesFromDir($dir, $extensions = []) {
        $files = [];
        foreach (scandir($dir) as $file) {
            if ($file !== '.' && $file !== '..') {
                $filePath = $dir . '/' . $file;
                if (is_dir($filePath)) {
                    // Recherche récursive dans les sous-dossiers
                    $files = array_merge($files, $this->getFilesFromDir($filePath, $extensions));
                } elseif (is_file($filePath)) {
                    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                    if (empty($extensions) || in_array($ext, $extensions)) {
                        $files[] = $filePath;
                    }
                }
            }
        }
        return $files;
    }

	// Fonction pour scanner récursivement les dossiers
	function scanFolders($dir, $searchText, $zip) {
		$files = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator($dir),
			RecursiveIteratorIterator::SELF_FIRST
		);

		foreach ($files as $file) {
			if ($file->isFile() && pathinfo($file, PATHINFO_EXTENSION) === 'txt') {
				$content = file_get_contents($file->getPathname());
				if (strpos($content, $searchText) !== false) {
					$relativePath = substr($file->getPathname(), strlen($dir) + 1);
					$zip->addFile($file->getPathname(), $relativePath);
					echo "Ajout de : " . $relativePath . "\n";
				}
			}
		}
	}
	
	/**
	 * Overloading the doActions function : replacing the parent's function with the one below
	 *
	 * @param   array           $parameters     Hook metadatas (context, etc...)
	 * @param   CommonObject    $object         The object to process (an invoice if you are in invoice module, a propale in propale's module, etc...)
	 * @param   string          $action         Current action (if set). Generally create or edit or null
	 * @param   HookManager     $hookmanager    Hook manager propagated to allow calling another hook
	 * @return  int                             Return integer < 0 on error, 0 on success, 1 to replace standard code
	 */
	public function doActions($parameters, &$object, &$action, $hookmanager)
	{
		global $conf, $user, $langs;

		$error = 0; // Error counter

		/* print_r($parameters); print_r($object); echo "action: " . $action; */
		if (in_array($parameters['currentcontext'], array('somecontext1', 'somecontext2'))) {	    // do something only for the context 'somecontext1' or 'somecontext2'
			// Do what you want here...
			// You can for example load and use call global vars like $fieldstosearchall to overwrite them, or update database depending on $action and GETPOST values.
		}

		$contexts = explode(':', $parameters['context']);
		if (in_array('thirdpartycard', $contexts)) {
			// Proposer la possibilité de choisir les documents a récuperer
			/**
			 * @var Societe $object
			 */
			if ($action == 'generezipDoliZipExport') {
				$chemin = DOL_DOCUMENT_ROOT .'/documents/';
				$scandir = scandir($chemin);

				$FolderName = [];
				foreach ($scandir as $folder) {
					if ($folder !== '..' && $folder != '.' && strpos($folder, '.') === false && strpos($folder, '/') === false && strpos($folder, 'bom') === false) {
						$ext = strtolower(pathinfo($scandir, PATHINFO_EXTENSION));
						$folderMaj = ucfirst($folder);
						$cheminClasse = '';
						$bddName = $folder;
						$fk_socT = 1;

						switch ($folderMaj) { 
							case 'societe':
								if (empty($conf->global->DOLIZIPEXPORT_SOCIETE)) {
									break;
								}
								$fk_socT = 0;
								$folderMaj = 'Societe';
								$bddName = 'societe';
								break;
							case 'Facture':
								if (empty($conf->global->DOLIZIPEXPORT_INVOICE)) {
									break;
								}
								$cheminClasse = dol_buildpath('compta/'.$folder.'/class/'.$folder.'.class.php');
								break;
							case 'Banque':
								if (empty($conf->global->DOLIZIPEXPORT_BANK)) {
									break;
								}
								$cheminClasse = dol_buildpath('bank/class/account.class.php');
								$folderMaj = 'Account';
								break;
							case 'Propale':
								if (empty($conf->global->DOLIZIPEXPORT_PROPAL)) {
									break;
								}
								$cheminClasse = dol_buildpath('comm/propal/class/propal.class.php');
								$folderMaj = 'Propal';
								$bddName = 'propal';
								break;
							case 'Ficheinter':
								if (empty($conf->global->DOLIZIPEXPORT_FICHINTER)) {
									break;
								}
								$cheminClasse = dol_buildpath('fichinter/class/fichinter.class.php');
								$folderMaj = 'Fichinter';
								break;
							default:
								$cheminClasse = dol_buildpath($folder.'/class/'.$folder.'.class.php');
								$bddName = $folder;
								break;
						}
						include_once $cheminClasse;
						if (class_exists($folderMaj)) {
							$class = new $folderMaj($this->db);
							$propriete = '';
							// Vérifie si AU MOINS une des deux propriétés existe
							if ($class->fields['fk_soc'] || $class->fields['fk_soc']) {
								// $class = new $folderMaj($this->db);
								if ($class->element === 'propal') {
									$folderMaj = 'propale';
								}
								$propriete = !empty($class->fields['fk_soc']) ? 'fk_soc' : 'socid';
							}
							$FolderName[] = [
								'folder' => $folderMaj,
								'bddname' => $bddName,
								'propriete' => $propriete,
								'name' => $folder,
								'files' => [
									'images' => [],
									'pdfs' => []
								]
							];
						}
					}
				}

				$SqlComm = [];
				foreach ($FolderName as $key => &$folder) {
					if ($folder['folder'] === 'Societe') {
						$folderPath = DOL_DOCUMENT_ROOT.'/documents/societe/'.$object->id;
						if (is_dir($folderPath)) {
							$files = scandir($folderPath);
							foreach ($files as $file) {
								if ($file !== '.' && $file !== '..' && strpos($file, 'temp') === false) {
									$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
									if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
										$FolderName[$key]['files']['images'][] = $file; // Modifier directement l'élément
									} elseif ($ext === 'pdf') {
										$fileName = explode('.', $file);
										$FolderName[$key]['files']['pdfs'][$fileName[0]] = $file;
									}
								}
							}
						}
					} elseif (!empty($folder['propriete'])) {
						$sqlComm = 'SELECT * FROM '.MAIN_DB_PREFIX.''.$folder['bddname'];
						$sqlComm .= ' WHERE '.$folder['propriete'].' ='. $object->id;
						$resSqlComm = $this->db->getRows($sqlComm);
	
						if (!empty($resSqlComm)) {
							foreach ($resSqlComm as &$row) {
								$row->name = strtolower($folder['folder']);
								$row->refSocieteDoc = $row->ref;
							}
							unset($row);
							$SqlComm = array_merge($SqlComm ?? [], $resSqlComm);
						}
					}
				}
				if (!empty($SqlComm)) {
					// Pour chacune des commandes on l'ajoute au dossier folder
					foreach ($SqlComm as $dosc) {
						$folderPath = DOL_DOCUMENT_ROOT.'/documents/'.$dosc->name.'/'.$dosc->ref;
						if (is_dir($folderPath)) {
							$files = scandir($folderPath);
							foreach ($files as $file) {
								if ($file !== '.' && $file !== '..' && strpos($file, 'temp') === false) {
									$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
									foreach ($FolderName as &$folder) {
										// Vérifie si le nom du dossier correspond à l'entrée courante
										if (strtolower($folder['folder']) === strtolower($dosc->name)) {
											$folder['ref'] = $dosc->refSocieteDoc;
											if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
												$folder['files']['images'][] = $file;
											} elseif ($ext === 'pdf') {
												$fileName = explode('.', $file);
												$folder['files']['pdfs'][$fileName[0]] = $file;
											}
											// break; // Sort de la boucle une fois le bon dossier trouvé
										}
									}
								}
							}
						}
					}
				}

				// Chemin du dossier d'export
				$exportDir = DOL_DATA_ROOT.'/exports';
				if (!file_exists($exportDir)) {
					mkdir($exportDir, 0777, true);
				}

				// Nom du fichier ZIP
				$zipFileName = $exportDir.'/'.$object->nom.'_'.$object->id.'_'.date('Y-m-d').'.zip';
				$zip = new ZipArchive();
				if ($zip->open($zipFileName, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
					foreach ($FolderName as $folders) {
						foreach ($folders['files']['pdfs'] as $pdfFile => $val) {
							$pdfPath = DOL_DOCUMENT_ROOT.'/documents/'.$folders['name'].'/'.$pdfFile.'/'.$val;
							if (file_exists($pdfPath)) {
								$zip->addFile($pdfPath, $folders['name'].'/'.$val);
							}
						}
						if (!empty($conf->global->DOLIZIPEXPORT_IMG_ONZIP)) {
							foreach ($folders['files']['images'] as $imgFile) {
								if ($folders['folder'] === 'Societe') {
									$imgPath = DOL_DOCUMENT_ROOT.'/documents/'.$folders['name'].'/'.$object->id.'/'.$imgFile;
								} else {
									$imgPath = DOL_DOCUMENT_ROOT.'/documents/'.$folders['name'].'/'.$folders['ref'].'/'.$imgFile;
								}
								if (file_exists($imgPath)) {
									$zip->addFile($imgPath, $folders['name'].'/'.$imgFile);
								}
							}
						}
					}
					$zip->close();
					setEventMessage('Création du fichier zip réussi', 'mesgs');
					header('Location: '.DOL_URL_ROOT.'/societe/card.php?socid='.$object->id);
				} else {
					setEventMessage("Erreur lors de la création du fichier ZIP.", 'errors');
				}
			}

			if ($action === 'downloadFileZipDolizipept') {
				if (!isset($_GET['file']) || empty($_GET['file'])) {
					die('Fichier non spécifié.');
				}
				
				$file = basename($_GET['file']); // Sécurisation du nom du fichier
				$exportDir = DOL_DATA_ROOT.'/exports/';
				$filePath = $exportDir . $file;
				
				if (!file_exists($filePath)) {
					die('Le fichier n\'existe pas.');
				}
				
				// Définition des headers pour le téléchargement
				header('Content-Type: application/zip');
				header('Content-Disposition: attachment; filename="' . $file . '"');
				header('Content-Length: ' . filesize($filePath));
				
				// Lecture et envoi du fichier au client
				readfile($filePath);
				exit;
			}
		}

		if (!$error) {
			$this->results = array('myreturn' => 999);
			$this->resprints = 'A text to show';
			return 0; // or return 1 to replace standard code
		} else {
			$this->errors[] = 'Error message';
			return -1;
		}
	}

	/**
	 * Overloading the doMassActions function : replacing the parent's function with the one below
	 *
	 * @param   array           $parameters     Hook metadatas (context, etc...)
	 * @param   CommonObject    $object         The object to process (an invoice if you are in invoice module, a propale in propale's module, etc...)
	 * @param   string          $action         Current action (if set). Generally create or edit or null
	 * @param   HookManager     $hookmanager    Hook manager propagated to allow calling another hook
	 * @return  int                             Return integer < 0 on error, 0 on success, 1 to replace standard code
	 */
	public function doMassActions($parameters, &$object, &$action, $hookmanager)
	{
		global $conf, $user, $langs;

		$error = 0; // Error counter

		/* print_r($parameters); print_r($object); echo "action: " . $action; */
		if (in_array($parameters['currentcontext'], array('somecontext1', 'somecontext2'))) {		// do something only for the context 'somecontext1' or 'somecontext2'
			foreach ($parameters['toselect'] as $objectid) {
				// Do action on each object id
			}
		}

		if (!$error) {
			$this->results = array('myreturn' => 999);
			$this->resprints = 'A text to show';
			return 0; // or return 1 to replace standard code
		} else {
			$this->errors[] = 'Error message';
			return -1;
		}
	}


	/**
	 * Overloading the addMoreMassActions function : replacing the parent's function with the one below
	 *
	 * @param   array           $parameters     Hook metadatas (context, etc...)
	 * @param   CommonObject    $object         The object to process (an invoice if you are in invoice module, a propale in propale's module, etc...)
	 * @param   string          $action         Current action (if set). Generally create or edit or null
	 * @param   HookManager     $hookmanager    Hook manager propagated to allow calling another hook
	 * @return  int                             Return integer < 0 on error, 0 on success, 1 to replace standard code
	 */
	public function addMoreMassActions($parameters, &$object, &$action, $hookmanager)
	{
		global $conf, $user, $langs;

		$error = 0; // Error counter
		$disabled = 1;

		/* print_r($parameters); print_r($object); echo "action: " . $action; */
		if (in_array($parameters['currentcontext'], array('somecontext1', 'somecontext2'))) {		// do something only for the context 'somecontext1' or 'somecontext2'
			$this->resprints = '<option value="0"'.($disabled ? ' disabled="disabled"' : '').'>'.$langs->trans("DoliZipExportMassAction").'</option>';
		}

		if (!$error) {
			return 0; // or return 1 to replace standard code
		} else {
			$this->errors[] = 'Error message';
			return -1;
		}
	}

	public function addMoreActionsButtons($parameters, &$object, &$action)
	{
		global $conf, $user, $langs, $hookmanager;

		/**
		 * @var Societe $object
		 */
		$contexts = explode(':', $parameters['context']);
		if (in_array('thirdpartycard', $contexts)) {
			require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';

			$societe = new Societe($this->db);
			$societe->fetch($object->id);

			$exportDir = DOL_DATA_ROOT.'/exports/';
			$scan = scandir($exportDir);

			$fileZip = [];
			foreach ($scan as $folder) {
				if ($folder !== '..' && $folder !== '.') {
					$name = explode('_', $folder);
					if ($name[0] === $object->nom && $name[1] === $object->id) {
						$fileZip[] = $folder;
					}
				}
			}

			print '<a class="butActionDelete classfortooltip" href="'.DOL_URL_ROOT.'/societe/card.php?socid='.$societe->id.'&action=generezipDoliZipExport">'.$langs->trans('GenrZipTiers').'</a>';

			$zipBtn = ''; // Initialisation de la variable
			foreach ($fileZip as $file) {
				if (file_exists($exportDir . $file)) {
					$zipBtn .= '<a class="classfortooltip btn btn-primary dolizipexporta" href="'.DOL_URL_ROOT.'/societe/card.php?socid='.$object->id.'&action=downloadFileZipDolizipept&file=' . urlencode($file) . '">' . htmlspecialchars($file) . '</a><br>';
				}
			}

			?>
			<script>
				const divact = document.querySelector('.tabsAction');
				let tablediv = "<h3>Download Zip file</h3>" + <?php echo json_encode($zipBtn, JSON_HEX_TAG); ?>;
			
				const tblDiv = document.createElement("div");
				tblDiv.className = "dolizipexpdiv";
				tblDiv.innerHTML = tablediv;

				divact.insertAdjacentElement("afterend", tblDiv);
			</script>
			<?php

			return 0;
		}
	}

	/**
	 * Execute action
	 *
	 * @param	array	$parameters     Array of parameters
	 * @param   Object	$object		   	Object output on PDF
	 * @param   string	$action     	'add', 'update', 'view'
	 * @return  int 		        	Return integer <0 if KO,
	 *                          		=0 if OK but we want to process standard actions too,
	 *  	                            >0 if OK and we want to replace standard actions.
	 */
	public function beforePDFCreation($parameters, &$object, &$action)
	{
		global $conf, $user, $langs;
		global $hookmanager;

		$outputlangs = $langs;

		$ret = 0;
		$deltemp = array();
		dol_syslog(get_class($this).'::executeHooks action='.$action);

		/* print_r($parameters); print_r($object); echo "action: " . $action; */
		if (in_array($parameters['currentcontext'], array('somecontext1', 'somecontext2'))) {		// do something only for the context 'somecontext1' or 'somecontext2'
		}

		return $ret;
	}

	/**
	 * Execute action
	 *
	 * @param	array	$parameters     Array of parameters
	 * @param   Object	$pdfhandler     PDF builder handler
	 * @param   string	$action         'add', 'update', 'view'
	 * @return  int 		            Return integer <0 if KO,
	 *                                  =0 if OK but we want to process standard actions too,
	 *                                  >0 if OK and we want to replace standard actions.
	 */
	public function afterPDFCreation($parameters, &$pdfhandler, &$action)
	{
		global $conf, $user, $langs;
		global $hookmanager;

		$outputlangs = $langs;

		$ret = 0;
		$deltemp = array();
		dol_syslog(get_class($this).'::executeHooks action='.$action);

		/* print_r($parameters); print_r($object); echo "action: " . $action; */
		if (in_array($parameters['currentcontext'], array('somecontext1', 'somecontext2'))) {
			// do something only for the context 'somecontext1' or 'somecontext2'
		}

		return $ret;
	}



	/**
	 * Overloading the loadDataForCustomReports function : returns data to complete the customreport tool
	 *
	 * @param   array           $parameters     Hook metadatas (context, etc...)
	 * @param   string          $action         Current action (if set). Generally create or edit or null
	 * @param   HookManager     $hookmanager    Hook manager propagated to allow calling another hook
	 * @return  int                             Return integer < 0 on error, 0 on success, 1 to replace standard code
	 */
	public function loadDataForCustomReports($parameters, &$action, $hookmanager)
	{
		global $langs;

		$langs->load("dolizipexport@dolizipexport");

		$this->results = array();

		$head = array();
		$h = 0;

		if ($parameters['tabfamily'] == 'dolizipexport') {
			$head[$h][0] = dol_buildpath('/module/index.php', 1);
			$head[$h][1] = $langs->trans("Home");
			$head[$h][2] = 'home';
			$h++;

			$this->results['title'] = $langs->trans("DoliZipExport");
			$this->results['picto'] = 'dolizipexport@dolizipexport';
		}

		$head[$h][0] = 'customreports.php?objecttype='.$parameters['objecttype'].(empty($parameters['tabfamily']) ? '' : '&tabfamily='.$parameters['tabfamily']);
		$head[$h][1] = $langs->trans("CustomReports");
		$head[$h][2] = 'customreports';

		$this->results['head'] = $head;

		$arrayoftypes = array();
		//$arrayoftypes['dolizipexport_myobject'] = array('label' => 'MyObject', 'picto'=>'myobject@dolizipexport', 'ObjectClassName' => 'MyObject', 'enabled' => isModEnabled('dolizipexport'), 'ClassPath' => "/dolizipexport/class/myobject.class.php", 'langs'=>'dolizipexport@dolizipexport')

		$this->results['arrayoftype'] = $arrayoftypes;

		return 0;
	}



	/**
	 * Overloading the restrictedArea function : check permission on an object
	 *
	 * @param   array           $parameters     Hook metadatas (context, etc...)
	 * @param   string          $action         Current action (if set). Generally create or edit or null
	 * @param   HookManager     $hookmanager    Hook manager propagated to allow calling another hook
	 * @return  int 		      			  	Return integer <0 if KO,
	 *                          				=0 if OK but we want to process standard actions too,
	 *  	                            		>0 if OK and we want to replace standard actions.
	 */
	public function restrictedArea($parameters, &$action, $hookmanager)
	{
		global $user;

		if ($parameters['features'] == 'myobject') {
			if ($user->hasRight('dolizipexport', 'myobject', 'read')) {
				$this->results['result'] = 1;
				return 1;
			} else {
				$this->results['result'] = 0;
				return 1;
			}
		}

		return 0;
	}

	/**
	 * Execute action completeTabsHead
	 *
	 * @param   array           $parameters     Array of parameters
	 * @param   CommonObject    $object         The object to process (an invoice if you are in invoice module, a propale in propale's module, etc...)
	 * @param   string          $action         'add', 'update', 'view'
	 * @param   Hookmanager     $hookmanager    hookmanager
	 * @return  int                             Return integer <0 if KO,
	 *                                          =0 if OK but we want to process standard actions too,
	 *                                          >0 if OK and we want to replace standard actions.
	 */
	public function completeTabsHead(&$parameters, &$object, &$action, $hookmanager)
	{
		global $langs, $conf, $user;

		if (!isset($parameters['object']->element)) {
			return 0;
		}
		if ($parameters['mode'] == 'remove') {
			// used to make some tabs removed
			return 0;
		} elseif ($parameters['mode'] == 'add') {
			$langs->load('dolizipexport@dolizipexport');
			// used when we want to add some tabs
			$counter = count($parameters['head']);
			$element = $parameters['object']->element;
			$id = $parameters['object']->id;
			// verifier le type d'onglet comme member_stats où ça ne doit pas apparaitre
			// if (in_array($element, ['societe', 'member', 'contrat', 'fichinter', 'project', 'propal', 'commande', 'facture', 'order_supplier', 'invoice_supplier'])) {
			if (in_array($element, ['context1', 'context2'])) {
				$datacount = 0;

				$parameters['head'][$counter][0] = dol_buildpath('/dolizipexport/dolizipexport_tab.php', 1) . '?id=' . $id . '&amp;module='.$element;
				$parameters['head'][$counter][1] = $langs->trans('DoliZipExportTab');
				if ($datacount > 0) {
					$parameters['head'][$counter][1] .= '<span class="badge marginleftonlyshort">' . $datacount . '</span>';
				}
				$parameters['head'][$counter][2] = 'dolizipexportemails';
				$counter++;
			}
			if ($counter > 0 && (int) DOL_VERSION < 14) {
				$this->results = $parameters['head'];
				// return 1 to replace standard code
				return 1;
			} else {
				// en V14 et + $parameters['head'] est modifiable par référence
				return 0;
			}
		} else {
			// Bad value for $parameters['mode']
			return -1;
		}
	}

	/* Add here any other hooked methods... */
}
